//21BCSE30 | ANIKET PATRA

import reverseNumber from "./reverseNumber.js";

const number = 12345;
console.log(`Original number: ${number}`);
const reversed = reverseNumber(number);
console.log(`Reversed number: ${reversed}`);
