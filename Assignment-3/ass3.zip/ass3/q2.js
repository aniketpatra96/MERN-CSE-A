//21BCSE30 | ANIKET PATRA
const square = (x) => x * x;
console.log(square(5));
