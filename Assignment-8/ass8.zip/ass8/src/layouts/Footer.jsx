import "../styles/footer.css";
export default function Footer() {
  return (
    <footer className="footer">
      <p>&copy; 21BCSE30 | ANIKET PATRA</p>
    </footer>
  );
}
