import PropTypes from "prop-types";

export default function UserCard({ user }) {
  const { image, firstName, lastName, phone, email, address } = user;
  return (
    <div className="card" style={{ width: "25rem", marginBottom: "2rem" }}>
      <img src={image} className="card-img-top" alt="User Photo" />
      <div className="card-body">
        <h5 className="card-title">
          {firstName}&nbsp;{lastName}
        </h5>
        <p className="card-text">
          {address.address}
          <br />
          CITY {address.city}
          <br />
          STATE {address.state}
          <br />
          PIN-CODE {address.postalCode}
        </p>
      </div>
      <ul className="list-group list-group-flush">
        <li className="list-group-item">Tel No. {phone}</li>
        <li className="list-group-item">Email {email}</li>
      </ul>
    </div>
  );
}

UserCard.propTypes={
    user: PropTypes.shape({
        image: PropTypes.string,
        firstName: PropTypes.string,
        lastName: PropTypes.string,
        phone: PropTypes.string,
        email: PropTypes.string,
        address: PropTypes.shape({
            address:PropTypes.string,
            street: PropTypes.string,
            city: PropTypes.string,
            state: PropTypes.string,
            postalCode: PropTypes.string,
        }).isRequired,
    })
}