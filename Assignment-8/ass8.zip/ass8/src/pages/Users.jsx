import UserCard from "../components/UserCard";
import axios from "axios";
import { useEffect, useState } from "react";
export default function Users() {
  const [users, setUsers] = useState(null);
  const getUsers = async () => {
    const users = await axios.get("https://dummyjson.com/users");
    setUsers(users.data.users);
  };
  useEffect(() => {
    getUsers();
  }, []);
  return (
    <div className="row">
      { users && users.map((user) => {
        return (
          <div key={user.id} className="col-md-4 col-sm-6">
            <UserCard user={user} />
          </div>
        );
      })}
    </div>
  );
}
