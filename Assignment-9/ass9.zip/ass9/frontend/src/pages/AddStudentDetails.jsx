import MyForm from "../components/MyForm";

const AddStudentDetails = () => {
  return <MyForm />;
};

export default AddStudentDetails;
