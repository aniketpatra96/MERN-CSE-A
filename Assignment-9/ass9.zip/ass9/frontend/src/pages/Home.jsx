/* eslint-disable react/no-unknown-property */
const Home = () => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        marginTop: "10rem",
        flexWrap: "wrap",
      }}
    >
      <marquee behavior="alternate" direction="" loop scrolldelay="10">
        <h1> Assignment 9 Homepage </h1>
      </marquee>
    </div>
  );
};

export default Home;
